import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { AnimatePresence, motion, MotionConfig } from "framer-motion";
import { Heart, Link2, Copy, Users, Sparkles, ArrowRight, LogOut, ShieldCheck, Send, Check, SkipForward, Pause, Play, Settings, RotateCcw, WifiOff } from "lucide-react";
import { isConfigured } from "./supabase";
import { categoryLabels } from "./content";
import { createRoom, getSnapshot, joinRoom, leaveRoom, nextInteraction, restartGame, setAdultConsent, setPause, setPlayerCategories, startGame, submitAnswer } from "./api";
import { decodePrediction, encodePrediction, extractRoomId, getSharedCategories, parseError, speakerSeat } from "./lib/protocol";
import type { Category, Player, Snapshot } from "./types";

type Identity = { roomId: string; token: string; nickname: string; avatar: "masculin" | "feminin" };
const categories: Category[] = ["decouverte", "complicite", "profondeur", "seduction", "audacieux"];
const KEY = "adeux_identity";
const readIdentity = (): Identity | null => { try { const r = localStorage.getItem(KEY); return r ? JSON.parse(r) : null; } catch { return null; } };
const saveIdentity = (v: Identity | null) => { try { v ? localStorage.setItem(KEY, JSON.stringify(v)) : localStorage.removeItem(KEY); } catch { /* stockage indisponible */ } };

type Mood = "idle" | "think" | "laugh" | "talk";
function Avatar({ gender, name, mood = "idle", bubble }: { gender: string; name?: string; mood?: Mood; bubble?: string }) {
  return <div className={`avatar ${gender} active mood-${mood}`} role="img" aria-label={`Personnage ${gender}${name ? ", " + name : ""}`}>
    {bubble && <div className="speech-bubble" role="status">{bubble}</div>}
    <div className="avatar-halo" /><div className="avatar-head"><div className="hair" /><div className="eyes"><i /><i /></div><div className="smile" /></div>
    <div className="avatar-body"><div className="neck" /></div>
    {name && <span className="avatar-name">{name}</span>}
  </div>;
}

export default function App() {
  const [identity, setIdentity] = useState<Identity | null>(() => readIdentity());
  const [snap, setSnap] = useState<Snapshot | null>(null);
  const [nickname, setNickname] = useState("");
  const [avatar, setAvatar] = useState<"masculin" | "feminin">("masculin");
  const [joinCode, setJoinCode] = useState(new URLSearchParams(location.search).get("room") || "");
  const [screen, setScreen] = useState<"home" | "profile" | "join">(() => (new URLSearchParams(location.search).get("room") ? "join" : "home"));
  const [selected, setSelected] = useState<Category[]>(["decouverte", "complicite", "profondeur", "seduction"]);
  const [answer, setAnswer] = useState(""); const [guess, setGuess] = useState("");
  const [busy, setBusy] = useState(false); const [error, setError] = useState(""); const [notice, setNotice] = useState("");
  const [offline, setOffline] = useState(false); const [copied, setCopied] = useState(false);
  const [menu, setMenu] = useState(false); const [reduced, setReduced] = useState(() => localStorage.getItem("adeux_reduced") === "1");
  const failures = useRef(0); const lastQuestion = useRef<string | null>(null); const inFlight = useRef(false);

  const dropSession = useCallback((message: string) => {
    saveIdentity(null); setIdentity(null); setSnap(null); setScreen("home"); setMenu(false);
    history.replaceState({}, "", location.pathname); setNotice(message);
  }, []);

  const refresh = useCallback(async () => {
    if (!identity || inFlight.current) return;
    inFlight.current = true;
    try {
      const data = await getSnapshot(identity.roomId, identity.token);
      failures.current = 0; setOffline(false); setSnap(data);
      if (data.room.status === "waiting" && data.my_categories?.length) setSelected(data.my_categories);
      const key = `${data.room.current_index}:${data.interaction_id}`;
      if (key !== lastQuestion.current) { lastQuestion.current = key; setAnswer(""); setGuess(""); }
    } catch (e) {
      const err = parseError(e);
      if (err.fatal) dropSession(err.message);            // salle inconnue/expirée/remplacée : on arrête, pas de boucle
      else { failures.current += 1; setOffline(true); }
    } finally { inFlight.current = false; }
  }, [identity, dropSession]);

  useEffect(() => { if (identity) void refresh(); }, [identity, refresh]);
  useEffect(() => {          // polling avec recul progressif en cas de coupure (2,2 s → 10 s)
    if (!identity) return;
    let stop = false; let t: number;
    const loop = () => { if (stop) return; void refresh().finally(() => { t = window.setTimeout(loop, Math.min(10000, 2200 + failures.current * 1500)); }); };
    t = window.setTimeout(loop, 2200);
    return () => { stop = true; window.clearTimeout(t); };
  }, [identity, refresh]);
  useEffect(() => { document.documentElement.dataset.reduced = reduced ? "1" : "0"; localStorage.setItem("adeux_reduced", reduced ? "1" : "0"); }, [reduced]);

  const inviteUrl = useMemo(() => identity ? `${location.origin}${location.pathname}?room=${identity.roomId}` : "", [identity]);
  const me = snap?.players.find(p => p.id === snap.my_player_id);
  const other = snap?.players.find(p => p.id !== snap?.my_player_id);
  const cur = snap?.interaction ?? null;
  const status = snap?.room.status;

  async function run(action: () => Promise<unknown>, after = true) {
    setBusy(true); setError("");
    try { await action(); if (after) await refresh(); }
    catch (e) { const err = parseError(e); if (err.fatal) dropSession(err.message); else setError(err.message); }
    finally { setBusy(false); }
  }
  async function enter(kind: "create" | "join") {
    const name = nickname.trim();
    if (name.length < 2) return setError("Choisis un pseudo d'au moins 2 caractères.");
    let roomId = "";
    if (kind === "join") { const id = extractRoomId(joinCode); if (!id) return setError("Lien ou identifiant de salle invalide."); roomId = id; }
    await run(async () => {
      const r = kind === "create" ? await createRoom(name, avatar) : await joinRoom(roomId, name, avatar);
      const next = { roomId: r.room_id, token: r.player_token, nickname: name, avatar };
      saveIdentity(next); lastQuestion.current = null; setNotice(""); setIdentity(next);
      history.replaceState({}, "", `${location.pathname}?room=${r.room_id}`);
    }, false);
  }
  const copyInvite = async () => { try { await navigator.clipboard.writeText(inviteUrl); setCopied(true); setTimeout(() => setCopied(false), 1800); } catch { setError("Copie impossible : sélectionne le lien affiché."); } };
  const toggleConsent = (v: boolean) => run(() => setAdultConsent(identity!.roomId, identity!.token, v));
  const launch = () => run(() => startGame(identity!.roomId, identity!.token, selected));
  const toggleCategory = (category: Category) => {
    const next = selected.includes(category) ? selected.filter(c => c !== category) : [...selected, category];
    if (next.length === 0) return setError("Garde au moins une catégorie.");
    setSelected(next);
    if (identity && snap?.room.status === "waiting") void run(() => setPlayerCategories(identity.roomId, identity.token, next));
  };
  const send = (pass = false) => {
    let text = answer;
    if (cur?.kind === "prediction") text = encodePrediction(answer, guess);
    if (cur?.kind === "challenge" && !text.trim()) text = "Défi relevé ✓";
    return run(() => submitAnswer(identity!.roomId, identity!.token, pass ? "" : text, pass));
  };
  const next = () => run(() => nextInteraction(identity!.roomId, identity!.token));
  const pause = (p: boolean) => run(() => setPause(identity!.roomId, identity!.token, p));
  async function exit() {
    if (identity) { try { await leaveRoom(identity.roomId, identity.token); } catch { /* on quitte quand même */ } }
    dropSession("Tu as quitté la salle.");
  }

  const canSend = cur && !busy && snap?.my_answer == null && status === "playing" &&
    (cur.kind === "challenge" ? true : cur.kind === "prediction" ? answer.trim() !== "" && guess.trim() !== "" : answer.trim() !== "") &&
    !(cur.kind === "cross" && snap?.my_seat === 2 && snap.first_answer == null && snap.first_player_present && !snap.other_submitted);
  const bothConsent = Boolean(snap && snap.players.length === 2 && snap.players.every(p => p.adult_consent));
  const sharedCategories = getSharedCategories(selected, snap?.other_categories);
  const wantsAdult = sharedCategories.includes("audacieux");
  const speaker = snap && cur ? speakerSeat(cur.kind, snap.room.current_index, snap.my_seat === 1 ? snap.my_answer != null : (snap.other_submitted || !snap.first_player_present)) : 1;
  const bubbleText = (p?: Player) => {
    if (!snap || !cur || !p || p.seat !== speaker) return undefined;
    if (snap.revealed) return "Vous avez choisi…";
    if (snap.my_answer != null) return "À toi de jouer";
    return cur.kind === "challenge" ? "Et si on essayait quelque chose ?" : snap.room.current_index === 0 ? "J'ai une idée…" : "Je veux te poser une question…";
  };
  const mood = (p?: Player): Mood => !snap ? "idle" : snap.revealed ? "laugh" : p?.seat === speaker ? "talk" : (snap.my_answer != null || snap.other_submitted) ? "think" : "idle";
  const nameOf = (id: string) => snap?.players.find(p => p.id === id)?.nickname ?? "Joueur";
  const renderAnswer = (a: { answer: string; passed: boolean }) => {
    if (a.passed) return <p className="muted">A choisi de passer.</p>;
    const pr = cur?.kind === "prediction" ? decodePrediction(a.answer) : null;
    return pr ? <p><b>Réponse :</b> {pr.own}<br /><b>Pronostic :</b> {pr.guess}</p> : <p>{a.answer}</p>;
  };

  if (!isConfigured) return <main className="setup-page"><div className="setup-card"><div className="brand-mark"><Heart fill="currentColor" /></div><p className="eyebrow">À DEUX · CONFIGURATION</p><h1>Le jeu est prêt à être connecté.</h1><p>Il manque la connexion Supabase (voir INSTALLATION.md). Les joueurs n'auront jamais à faire ces manipulations.</p></div></main>;

  const Picker = <div className="avatar-picker">{(["masculin", "feminin"] as const).map(g => <button key={g} className={avatar === g ? "chosen" : ""} aria-pressed={avatar === g} onClick={() => setAvatar(g)}><Avatar gender={g} />{g === "masculin" ? "Masculin" : "Féminin"}</button>)}</div>;

  return <MotionConfig reducedMotion={reduced ? "always" : "user"}><div className="app-shell">
    <header className="topbar">
      <button className="brand" onClick={() => { if (!identity) setScreen("home"); }}><span className="brand-mark small"><Heart fill="currentColor" /></span><span>à deux<span className="brand-dot">.</span></span></button>
      <div className="top-actions"><span className="secure"><ShieldCheck size={14} /> Partie privée</span>
        {identity && <button className="icon-button" onClick={() => setMenu(true)} aria-label="Pause et paramètres"><Settings /></button>}</div>
    </header>
    {offline && <div className="toast offline" role="status"><WifiOff size={16} /> Reconnexion… la partie est conservée.</div>}
    {notice && !identity && <div className="toast" role="status">{notice}<button onClick={() => setNotice("")} aria-label="Fermer">×</button></div>}
    {error && <div className="toast" role="alert">{error}<button onClick={() => setError("")} aria-label="Fermer">×</button></div>}

    {menu && identity && <div className="overlay" role="dialog" aria-modal="true" aria-label="Pause et paramètres"><div className="overlay-card">
      <h2>{status === "paused" ? "Partie en pause" : "Paramètres"}</h2>
      <label className="adult-consent"><input type="checkbox" checked={reduced} onChange={e => setReduced(e.target.checked)} /> Réduire les animations</label>
      {(status === "playing" || status === "paused") && <button className="secondary full" disabled={busy} onClick={() => pause(status === "playing")}>{status === "playing" ? <><Pause size={16} /> Mettre en pause pour les deux</> : <><Play size={16} /> Reprendre pour les deux</>}</button>}
      {snap?.room.status !== "waiting" && snap?.room.adult_enabled && <button className="secondary full" onClick={() => toggleConsent(false)}>Quitter le mode 18+ maintenant</button>}
      <button className="secondary full" onClick={exit}><LogOut size={16} /> Quitter la salle</button>
      <button className="primary full" onClick={() => setMenu(false)}>Fermer</button></div></div>}

    <AnimatePresence mode="wait">
      {!identity && screen === "home" && <motion.main key="home" className="hero page" initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
        <div className="hero-copy"><span className="eyebrow"><Sparkles size={14} /> LE JEU DES CONVERSATIONS</span><h1>Deux personnes.<br /><em>Mille choses</em><br />à se raconter.</h1><p>Un espace à deux pour rire, se découvrir, se surprendre et créer de vrais moments de complicité, même à distance.</p>
          <div className="hero-buttons"><button className="primary" onClick={() => { setScreen("profile"); setError(""); }}>Créer une partie <ArrowRight size={18} /></button><button className="secondary" onClick={() => { setScreen("join"); setError(""); }}>Rejoindre une partie <Link2 size={17} /></button></div>
          <div className="hero-note"><ShieldCheck size={16} /> Gratuit pour les joueurs · Sans téléchargement · À deux uniquement</div></div>
        <div className="hero-stage"><div className="stage-glow" /><div className="stage-avatars"><Avatar gender="masculin" mood="talk" bubble="J'ai une idée…" /><div className="heart-between"><Heart fill="currentColor" /></div><Avatar gender="feminin" mood="think" bubble="Je t'écoute ✨" /></div></div>
      </motion.main>}

      {!identity && (screen === "profile" || screen === "join") && <motion.main key={screen} className="narrow page" initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
        <button className="back-link" onClick={() => setScreen("home")}>← Retour</button>
        <span className="eyebrow">{screen === "profile" ? "AVANT DE COMMENCER" : "ON T'A INVITÉ ?"}</span><h1>{screen === "profile" ? "Comment t'appelle-t-on ?" : "Rejoins votre espace."}</h1>
        {screen === "join" && <><label className="field-label" htmlFor="code">Lien ou code de la salle</label><input id="code" className="text-input" value={joinCode} onChange={e => setJoinCode(e.target.value)} placeholder="https://…?room=…" /></>}
        <label className="field-label" htmlFor="nick">Ton pseudo</label><input id="nick" className="text-input" value={nickname} onChange={e => setNickname(e.target.value)} maxLength={20} placeholder="Ex. Alex" />
        <label className="field-label">Ton avatar</label>{Picker}
        <p className="muted small">Ton pseudo, ton avatar et tes réponses restent associés à cette salle temporaire. Aucun compte personnel n’est créé.</p>
        <button className="primary full" disabled={busy} onClick={() => enter(screen === "profile" ? "create" : "join")}>{busy ? "Connexion…" : screen === "profile" ? "Créer ma salle" : "Rejoindre la partie"} <ArrowRight size={18} /></button>
      </motion.main>}

      {identity && !snap && <motion.main key="loading" className="narrow page" initial={{ opacity: 0 }} animate={{ opacity: 1 }}><p className="muted" role="status">{offline ? "Connexion impossible pour le moment… nouvelle tentative." : "Chargement de la salle…"}</p></motion.main>}

      {identity && snap && status === "waiting" && <motion.main key="waiting" className="waiting page" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
        <span className="eyebrow">VOTRE SALLE PRIVÉE</span><h1>La complicité se prépare à deux.</h1>
        <div className="waiting-stage"><div className="waiting-person"><Avatar gender={me?.avatar || identity.avatar} name={me?.nickname || identity.nickname} /></div><div className="waiting-plus">+</div>
          <div className={`waiting-person ${other ? "" : "ghost"}`}>{other ? <Avatar gender={other.avatar} name={other.nickname} mood="talk" /> : <div className="empty-avatar"><Users /></div>}<span className={`status-pill ${other?.online ? "online" : "offline"}`}>{other ? (other.online ? "Connecté" : "Reconnexion…") : "En attente"}</span></div></div>
        <div className="invite-box"><span className="invite-label">TON LIEN D'INVITATION</span><div className="invite-row"><span>{inviteUrl}</span><button onClick={copyInvite}><Copy size={16} />{copied ? "Copié" : "Copier"}</button></div></div>
        {snap.players.length === 2 ? <section className="category-panel"><h2>Choisissez votre ambiance</h2>
          <div className="category-grid">{categories.map(c => <button key={c} aria-pressed={selected.includes(c)} className={`category-chip ${selected.includes(c) ? "selected" : ""} ${c === "audacieux" ? "adult-chip" : ""}`} disabled={busy} onClick={() => toggleCategory(c)}>{selected.includes(c) ? "✓ " : "＋ "}{categoryLabels[c]}</button>)}</div>
          <p className="muted small">{sharedCategories.length ? `Catégories communes : ${sharedCategories.map(c => categoryLabels[c]).join(", ")}.` : "Vous n'avez pas encore de catégorie en commun. Choisissez au moins une ambiance identique."}</p>
          <label className="adult-consent"><input type="checkbox" checked={snap.my_consent} onChange={e => toggleConsent(e.target.checked)} /> Je suis majeur(e) et j'accepte la catégorie 18+ (facultative, sans contenu explicite).</label>
          <p className="muted small">{other?.adult_consent ? `${other.nickname} a accepté le mode 18+.` : `${other?.nickname ?? "L'autre joueur"} n'a pas accepté le mode 18+.`} Il faut l'accord des deux ; chacun peut le retirer à tout moment.</p>
          <button className="primary full" disabled={busy || sharedCategories.length === 0 || (wantsAdult && !bothConsent)} onClick={launch}>{sharedCategories.length === 0 ? "Choisissez une catégorie commune" : wantsAdult && !bothConsent ? "En attente de l'accord des deux (18+)" : "Lancer la partie"} <ArrowRight size={18} /></button></section>
          : <div className="waiting-status"><span className="pulse-dot" />En attente de la deuxième personne…</div>}
      </motion.main>}

      {identity && snap && (status === "playing" || status === "paused") && <motion.main key="game" className="game-page page" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
        <div className="game-top"><span className="eyebrow">VOTRE MOMENT À DEUX</span><span className="round-label">{snap.room.current_index + 1} / {snap.room.total}</span></div>
        <div className="game-scene"><div className="game-avatars">
          <div className="game-player"><Avatar gender={me?.avatar || "masculin"} name={me?.nickname} mood={mood(me)} bubble={bubbleText(me)} /></div><div className="scene-heart"><Heart fill="currentColor" /></div>
          <div className="game-player"><Avatar gender={other?.avatar || "feminin"} name={other?.nickname ?? "L'autre joueur"} mood={mood(other)} bubble={bubbleText(other)} />{other && !other.online && <span className="status-pill offline">Reconnexion…</span>}</div></div></div>
        {status === "paused" && <div className="question-card" role="status"><h2>Partie en pause</h2><p>Ouvre les paramètres pour reprendre.</p><button className="primary full" onClick={() => setMenu(true)}>Reprendre</button></div>}
        {status === "playing" && cur && <section className="question-card"><div className="question-meta"><span>{categoryLabels[cur.category]}</span><span>{({ secret: "CHOIX SECRET", challenge: "MINI-DÉFI (FACULTATIF)", prediction: "PRÉDICTION", cross: "QUESTION CROISÉE", free: "QUESTION OUVERTE" } as const)[cur.kind]}</span></div>
          <h1>{cur.title}</h1><p className="question-prompt">{cur.prompt}</p>
          {cur.kind === "cross" && snap.my_seat === 2 && snap.first_answer && <blockquote className="reveal-answer"><b>{other?.nickname}</b><p>{snap.first_answer}</p></blockquote>}
          {!snap.revealed && <>
            {cur.options ? <div className="option-list" role="radiogroup">{cur.options.map(o => <button key={o} role="radio" aria-checked={answer === o} disabled={snap.my_answer != null} className={`option ${(snap.my_answer ?? answer) === o ? "selected" : ""}`} onClick={() => setAnswer(o)}>{o}{(snap.my_answer ?? answer) === o && <Check size={16} />}</button>)}</div>
              : cur.kind === "challenge" ? <textarea className="answer-input" aria-label="Ton message (facultatif)" value={snap.my_answer ?? answer} onChange={e => setAnswer(e.target.value)} disabled={snap.my_answer != null} placeholder="Écris-le ici, ou valide simplement « défi relevé »." />
              : <><textarea className="answer-input" aria-label="Ta réponse" value={snap.my_answer != null ? (decodePrediction(snap.my_answer)?.own ?? snap.my_answer) : answer} onChange={e => setAnswer(e.target.value)} disabled={snap.my_answer != null} placeholder={cur.kind === "cross" && snap.my_seat === 2 ? "Ta réaction…" : "Ta réponse…"} />
                {cur.kind === "prediction" && <textarea className="answer-input" aria-label="Ton pronostic" value={snap.my_answer != null ? (decodePrediction(snap.my_answer)?.guess ?? "") : guess} onChange={e => setGuess(e.target.value)} disabled={snap.my_answer != null} placeholder="Ton pronostic sur l'autre…" />}</>}
            <div className="answer-actions"><button className="secondary" onClick={() => send(true)} disabled={busy || snap.my_answer != null}><SkipForward size={16} /> Passer</button>
              <button className="primary" onClick={() => send(false)} disabled={!canSend}>{snap.my_answer != null ? "Réponse envoyée" : "Valider"} <Send size={16} /></button></div>
            <p className="waiting-answer" role="status">{snap.my_answer != null ? "Ta réponse est enregistrée. En attente de l'autre…" : snap.other_submitted ? "L'autre personne a répondu. À toi !" : cur.kind === "cross" && snap.my_seat === 2 ? "Attends la réponse du premier joueur pour réagir." : "Les réponses restent cachées jusqu'à la révélation."}</p></>}
          {snap.revealed && <><div className="reveal-grid">{snap.answers.map(a => <div className="reveal-answer" key={a.player_id}><b>{nameOf(a.player_id)}</b>{renderAnswer(a)}</div>)}</div>
            <button className="primary full" disabled={busy || snap.i_acked} onClick={next}>{snap.i_acked ? "En attente de l'autre…" : snap.room.current_index + 1 >= snap.room.total ? "Terminer" : "Interaction suivante"} {!snap.i_acked && <ArrowRight size={18} />}</button>
            {snap.other_acked && !snap.i_acked && <p className="waiting-answer" role="status">L'autre est prêt·e.</p>}</>}
        </section>}
      </motion.main>}

      {identity && snap && status === "finished" && <motion.main key="end" className="game-page page" initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
        <div className="question-card"><h1>La session est terminée ✨</h1><p>{snap.summary ? `${snap.summary.answered} réponses partagées, ${snap.summary.passed} passages (sans pénalité).` : "Merci pour ce moment partagé."}</p>
          <button className="primary full" disabled={busy} onClick={() => run(() => restartGame(identity.roomId, identity.token))}><RotateCcw size={16} /> Rejouer</button>
          <button className="secondary full" onClick={exit}>Quitter la salle</button></div></motion.main>}
    </AnimatePresence>
    <footer className="footer"><span>à deux<span className="brand-dot">.</span> · Un espace pour se retrouver</span><span>Respect · Consentement · Complicité</span></footer>
  </div></MotionConfig>;
}
