# Guide de test à deux appareils (à faire sur un projet Supabase de TEST)

Prérequis : `01_schema.sql` + `02_catalog.sql` exécutés, `.env` rempli, `npm run dev` (ou URL déployée).
Appareil A = téléphone, appareil B = autre navigateur/profil privé. Cocher chaque ligne seulement après l'avoir réellement observée.

1. ☐ A crée une salle, copie le lien. B l'ouvre : le champ « lien » est prérempli, B rejoint avec son pseudo/avatar.
2. ☐ Un 3e navigateur ouvre le lien : message « salle complète ».
3. ☐ A coche 18+ seul : « Lancer » reste bloqué tant que B n'a pas coché. Après accord des deux, lancement OK.
4. ☐ Choix secret : A valide ; sur B rien n'est visible. B valide : les deux voient la révélation en même temps.
5. ☐ A clique « Interaction suivante » (même 3 fois) : B reste sur l'écran, voit « L'autre est prêt·e » ; B clique : les deux avancent une seule fois.
6. ☐ Question croisée : B ne peut pas valider avant A ; B voit la réponse de A.
7. ☐ Pause depuis A : B voit la pause, ne peut plus répondre ; reprise depuis B.
8. ☐ Pendant le jeu 18+, B ouvre ⚙ → « Quitter le mode 18+ » : A et B sortent immédiatement des interactions 18+.
9. ☐ Actualiser la page de A : retour dans la salle au même état.
10. ☐ Couper le réseau de B 20 s : bandeau « Reconnexion… », retour sans perte. Couper > 2 min : A n'est pas bloqué ; un nouveau joueur peut reprendre la place ; l'ancien B voit « place reprise ».
11. ☐ Fin de partie : récapitulatif, « Rejouer » ramène à la salle d'attente.
12. ☐ Écran 360 px de large, mode « réduire les animations ».

Tests automatisés locaux : `npm test` (helpers + catalogue) ; scénario SQL de sécurité et de parcours : voir `supabase/tests/scenario.sql` (PostgreSQL ≥ 15). Le test vérifie aussi que le consentement 18+ est redemandé lorsqu’une nouvelle partie est lancée.
