# À Deux — jeu relationnel interactif

Application web privée à deux joueurs : création de salle, invitation par lien, choix de catégories communes, réponses cachées, révélation et progression synchronisée.

## Déploiement Netlify

Le paquet de sources est dans `a-deux-source.tar.gz`. Netlify est configuré pour l'extraire, installer les dépendances et construire le site. Importer ce dépôt depuis GitHub sur Netlify ; le fichier `netlify.toml` configure déjà la commande et le dossier `dist`.

Définir dans les variables d'environnement Netlify :
- `VITE_SUPABASE_URL` : URL du projet Supabase ;
- `VITE_SUPABASE_ANON_KEY` : clé publique `publishable` du projet.

Ne jamais ajouter de fichier `.env`, de clé `service_role` ou de clé secrète au dépôt. Le workflow GitHub Actions vérifie automatiquement les tests et le build à chaque push.

## Sources

Le code source complet, les scripts SQL, les tests et la documentation sont contenus dans `a-deux-source.tar.gz`. Le paquet exclut `.env`, `node_modules` et `dist`.
