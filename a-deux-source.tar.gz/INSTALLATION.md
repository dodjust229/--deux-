# À DEUX — installation, vérification et publication

## 1. Ce qui est déjà configuré
Le projet utilise le backend Supabase déjà configuré. Le schéma SQL et les 43 interactions du catalogue sont déjà installés sur ce projet. Le fichier `.env` local peut être présent dans ton archive, mais il est volontairement exclu de GitHub. **Ne réexécute pas les fichiers SQL sur ce projet**, sauf si une migration précise te le demande.

La clé présente dans `.env` est une clé publique `publishable`, prévue pour être utilisée dans le navigateur. Elle n’est pas une clé `service_role`. Ne place jamais une clé secrète ou `service_role` dans une application Vite ou dans GitHub.

## 2. Lancer le jeu sur ton ordinateur
Prérequis : Node.js 22 LTS ou une version récente compatible.

1. Décompresse l’archive.
2. Ouvre un terminal dans le dossier `jeu-relationnel`.
3. Installe les dépendances et lance le serveur :

```bash
npm ci
npm run dev
```

4. Ouvre l’adresse locale affichée par Vite (généralement `http://localhost:5173`).

Le fichier `.env` est déjà inclus dans l’archive configurée. Si tu le supprimes, recrée-le à partir de `.env.example` et renseigne `VITE_SUPABASE_URL` et `VITE_SUPABASE_ANON_KEY`. Après toute modification de `.env`, redémarre Vite.

## 3. Fonctionnement
- Une personne crée une salle et partage le lien d’invitation.
- La seconde personne ouvre le lien, choisit son pseudo et son avatar, puis rejoint la salle.
- Les deux choisissent les catégories ; le mode 18+ est facultatif et nécessite l’accord explicite des deux personnes.
- Chaque partie tire jusqu’à 24 interactions parmi les 43 du catalogue.
- Les réponses restent privées jusqu’à ce que les personnes requises aient répondu. La progression suivante nécessite l’accord des deux personnes présentes.
- Les joueurs n’ont pas à créer de compte. Le navigateur conserve localement le jeton de session nécessaire à la reconnexion.

## 4. Vérification à deux navigateurs
Pour tester, ouvre le jeu dans deux navigateurs ou dans une fenêtre privée distincte :
1. Le navigateur A crée une salle et copie le lien.
2. Le navigateur B ouvre ce lien et rejoint la salle.
3. Vérifie que les deux pseudos et avatars apparaissent.
4. Lance une partie et vérifie qu’une réponse n’est pas révélée avant l’autre.
5. Vérifie que « Suivant » ne fait avancer la salle qu’après l’accord des deux personnes.
6. Essaie la pause, la reprise, l’actualisation et une coupure réseau.
7. Vérifie qu’un troisième joueur ne peut pas occuper une troisième place.

Les tests automatisés disponibles :

```bash
npm test
npm run build
```

Le test automatisé vérifie les fonctions pures et la cohérence du catalogue. Le scénario SQL détaillé est dans `supabase/tests/scenario.sql`. Un test de fumée du backend Supabase à deux joueurs a déjà confirmé la création, la jonction, les réponses masquées, la révélation et l’avancement synchronisé. Le parcours visuel complet dans deux navigateurs reste à effectuer.

## 5. Synchronisation et conservation des données
- La synchronisation se fait par interrogations périodiques de Supabase, et non par WebSocket/Realtime. Le délai normal est d’environ 2,2 secondes ; il augmente temporairement en cas de coupure réseau.
- Une place peut être reprise après 120 secondes d’absence.
- Les salles inactives depuis 6 heures sont supprimées par la fonction de nettoyage lorsqu’une nouvelle salle est créée. **Aucun nettoyage planifié permanent n’est configuré à ce stade** ; un cron pourra être ajouté si nécessaire.
- Le projet ne crée pas de compte utilisateur. Le jeton de session est conservé dans le stockage local du navigateur ; sa seule empreinte est enregistrée côté base. Les réponses et informations de salle sont temporaires.
- L’accord 18+ est une déclaration des deux joueurs, pas une vérification d’identité ou d’âge.

## 6. Publication gratuite (optionnelle)
Le projet peut être publié sur Netlify (ou un autre hébergeur statique compatible) :
- commande de build : `npm run build`
- dossier de sortie : `dist`
- variables d’environnement : `VITE_SUPABASE_URL` et `VITE_SUPABASE_ANON_KEY`

Le dépôt GitHub peut être public ou privé. Ne pousse jamais de clé `service_role` ni de fichier `.env`. Le fichier `.env` est ignoré par Git grâce à `.gitignore` ; configure les deux variables `VITE_SUPABASE_URL` et `VITE_SUPABASE_ANON_KEY` dans les paramètres de Netlify. Le fichier `netlify.toml` contient déjà la commande de build, le dossier `dist` et la règle nécessaire aux liens de salle. Une vérification automatique GitHub Actions exécute `npm ci`, `npm test` et `npm run build` à chaque mise à jour de `main`. Les offres gratuites ont des quotas et conditions susceptibles de changer : un coût nul n’est pas garanti en cas de dépassement.

## 7. Dépannage
- **« Le serveur n’est pas encore configuré »** : vérifie que `.env` est à la racine du dossier et que les deux variables commencent par `VITE_`, puis redémarre Vite.
- **« Invalid API key »** : vérifie que l’URL et la clé publique correspondent au même projet Supabase.
- **Salle introuvable/expirée** : vérifie le lien et le projet Supabase configuré.
- **Salle complète** : les deux places sont déjà occupées ; une reprise n’est possible qu’après le délai d’absence prévu.
- **Synchronisation lente** : le jeu utilise le polling ; vérifie la connexion Internet des deux appareils.
